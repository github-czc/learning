package com.alipay.demo.trade.model.hb;

/**
 * Created by liuyangkly on 15/8/27.
 */
public enum Product {
    FP // 当面付产品

    ,MP  // 医疗产品
}
